package ru.yandex.qatools.htmlelements.testelements;

/**
 * @author Alexander Tolmachev starlight@yandex-team.ru
 *         Date: 26.02.13
 */
public class NotAnnotatedExtendedCompany extends Company {
    //
}
