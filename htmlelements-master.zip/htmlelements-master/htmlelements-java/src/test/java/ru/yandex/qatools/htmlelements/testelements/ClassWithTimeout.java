package ru.yandex.qatools.htmlelements.testelements;

import ru.yandex.qatools.htmlelements.annotations.Timeout;
import ru.yandex.qatools.htmlelements.element.HtmlElement;

@Timeout(2)
public class ClassWithTimeout extends HtmlElement {
}
